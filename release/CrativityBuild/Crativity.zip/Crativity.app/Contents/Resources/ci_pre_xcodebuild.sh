#!/bin/sh
# This is not needed as our Xcode pre install is doing this
#for f in ../ThirdParty/FileWatcher/*.swift
#do
#   cp -v $f ../Pods/FileWatcher/$f
#done
