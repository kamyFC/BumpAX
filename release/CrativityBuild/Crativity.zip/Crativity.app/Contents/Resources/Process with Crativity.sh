if pgrep "Crativity"; then
    open "$@" -a /Applications/Crativity.app
    echo "Crativity is running...." > /tmp/com.cfloinc.Crativity.menu.service.txt
else
    open /Applications/Crativity.app --args "$@"
    echo ">>>>>>>>Not Found Crativity" > /tmp/com.cfloinc.Crativity.menu.service.txt
fi
