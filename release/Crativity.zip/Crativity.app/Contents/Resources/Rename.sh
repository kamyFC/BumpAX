mv "/Applications/Crativity.app" "/Applications/Crativity 2.app"
open /Applications/Crativity\ 2.app
